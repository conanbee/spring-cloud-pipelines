#!/bin/bash

docker-compose stop